# Generated Documentation
The `docs/` directory contains **automatically generated** documentation from the plugins and modules in this collection.

**Please do not submit pull requests to edit this documentation directly.** Instead, open a pull request to the `.py` file that contains the content these files are generated from.
